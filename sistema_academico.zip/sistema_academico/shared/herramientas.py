def imprimir_titulo(texto):
    print("\n" + "=" * 50)
    print(f"  {texto}")
    print("=" * 50)


def imprimir_exito(mensaje):
    print(f"\n[OK] {mensaje}")


def imprimir_error(mensaje):
    print(f"\n[ERROR] {mensaje}")


def imprimir_info(mensaje):
    print(f"\n[INFO] {mensaje}")


def confirmar(pregunta):
    respuesta = input(f"{pregunta} (s/n): ").strip().lower()
    return respuesta in ("s", "si", "sí", "y", "yes")
