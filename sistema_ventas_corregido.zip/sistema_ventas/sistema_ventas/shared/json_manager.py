import json
import os


class GestorJSON:
    def __init__(self, archivo):
        self.archivo = archivo
        carpeta = os.path.dirname(archivo)
        if carpeta and not os.path.exists(carpeta):
            os.makedirs(carpeta, exist_ok=True)
        if not os.path.exists(archivo):
            self.guardar([])

    def leer(self):
        try:
            with open(self.archivo, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def guardar(self, datos):
        try:
            with open(self.archivo, "w", encoding="utf-8") as f:
                json.dump(datos, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            return False
