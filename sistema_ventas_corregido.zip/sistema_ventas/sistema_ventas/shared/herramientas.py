def imprimir_titulo(texto):
    print("\\n" + "=" * 50)
    print(f"  {texto}")
    print("=" * 50)

def imprimir_exito(mensaje):
    print(f"\\n[OK] {mensaje}")

def imprimir_error(mensaje):
    print(f"\\n[ERROR] {mensaje}")

def imprimir_info(mensaje):
    print(f"\\n[INFO] {mensaje}")

def confirmar(pregunta):
    return input(f"{pregunta} (s/n): ").strip().lower() in ("s", "si", "sí", "y", "yes")

def imprimir_pausa():
    input("\\nPresione Enter para continuar...")

def pedir_entero(texto):
    try:
        return int(input(texto).strip())
    except (ValueError, TypeError):
        return None
