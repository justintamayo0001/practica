from shared.herramientas import (
    imprimir_titulo, imprimir_exito, imprimir_error, imprimir_info, confirmar, imprimir_pausa, pedir_entero
)
from controllers import (
    ClienteController, ProveedorController, ProductoController, VentaController, CompraController
)


class MenuCRUD:
    def __init__(self, controlador, titulo):
        self._controlador = controlador
        self._titulo = titulo
        self._activo = True

    def ejecutar(self):
        while self._activo:
            imprimir_titulo(self._titulo)
            print(f"  1. Crear {self._controlador.nombre}")
            print("  2. Ver todos")
            print("  3. Buscar")
            print("  4. Ver por id")
            print("  5. Actualizar")
            print("  6. Eliminar")
            print("  0. Volver\n")
            opcion = input("Opción: ").strip()

            if opcion == "1":
                self.crear()
            elif opcion == "2":
                self.ver_todos()
            elif opcion == "3":
                self.buscar()
            elif opcion == "4":
                self.ver_por_id()
            elif opcion == "5":
                self.actualizar()
            elif opcion == "6":
                self.eliminar()
            elif opcion == "0":
                self._activo = False
            else:
                imprimir_error("Opción no válida")
                imprimir_pausa()
        self._activo = True

    def crear(self):
        imprimir_titulo(f"CREAR {self._controlador.nombre.upper()}")
        datos = {}
        for campo in self._controlador.campos:
            datos[campo] = input(f"{campo.capitalize()}: ")

        exito, mensaje = self._controlador.crear(datos)
        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)
        imprimir_pausa()

    def ver_todos(self):
        imprimir_titulo(self._titulo)
        lista = self._controlador.leer()
        if len(lista) == 0:
            imprimir_info("No hay registros todavía.")
        else:
            for objeto in lista:
                print(f"  {objeto}")
            imprimir_info(f"Total: {len(lista)}")
        imprimir_pausa()

    def buscar(self):
        imprimir_titulo(f"BUSCAR {self._controlador.nombre.upper()}")
        texto = input("Buscar: ")
        encontrados = self._controlador.buscar(texto)
        if len(encontrados) == 0:
            imprimir_info(f"Sin coincidencias para '{texto}'.")
        else:
            for objeto in encontrados:
                print(f"  {objeto}")
        imprimir_pausa()

    def ver_por_id(self):
        imprimir_titulo(f"VER {self._controlador.nombre.upper()}")
        id_registro = pedir_entero("Id: ")
        objeto = self._controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error("No encontrado")
        else:
            for clave, valor in objeto.a_diccionario().items():
                print(f"  {clave.capitalize()}: {valor}")
        imprimir_pausa()

    def actualizar(self):
        imprimir_titulo(f"ACTUALIZAR {self._controlador.nombre.upper()}")
        id_registro = pedir_entero("Id: ")
        objeto = self._controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error("No encontrado")
            imprimir_pausa()
            return

        imprimir_info(f"Editando: {objeto.etiqueta()}")
        print("Deje en blanco lo que no quiera cambiar.\n")
        cambios = {}
        for campo in self._controlador.campos:
            actual = getattr(objeto, campo)
            nuevo = input(f"{campo.capitalize()} [{actual}]: ").strip()
            if nuevo != "":
                cambios[campo] = nuevo

        exito, mensaje = self._controlador.actualizar(id_registro, cambios)
        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)
        imprimir_pausa()

    def eliminar(self):
        imprimir_titulo(f"ELIMINAR {self._controlador.nombre.upper()}")
        id_registro = pedir_entero("Id: ")
        objeto = self._controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error("No encontrado")
            imprimir_pausa()
            return

        imprimir_info(f"Se eliminará: {objeto.etiqueta()}")
        if confirmar("¿Confirma?"):
            exito, mensaje = self._controlador.eliminar(id_registro)
            if exito:
                imprimir_exito(mensaje)
            else:
                imprimir_error(mensaje)
        else:
            imprimir_info("Operación cancelada")
        imprimir_pausa()


class MenuVentas(MenuCRUD):
    def __init__(self, controlador):
        super().__init__(controlador, "VENTAS")

    def ejecutar(self):
        while self._activo:
            imprimir_titulo(self._titulo)
            print(f"  1. Crear {self._controlador.nombre}")
            print("  2. Ver todos")
            print("  3. Buscar")
            print("  4. Ver por id")
            print("  5. Actualizar")
            print("  6. Eliminar")
            print("  7. Ver factura")
            print("  0. Volver\n")
            opcion = input("Opción: ").strip()

            if opcion == "1":
                self.crear_venta_personalizada()
            elif opcion == "2":
                self.ver_todos()
            elif opcion == "3":
                self.buscar()
            elif opcion == "4":
                self.ver_por_id()
            elif opcion == "5":
                imprimir_error("Las ventas registradas no se pueden modificar")
                imprimir_pausa()
            elif opcion == "6":
                imprimir_error("No se permite eliminar ventas para conservar la trazabilidad del inventario.")
                imprimir_pausa()
            elif opcion == "7":
                self.ver_factura()
            elif opcion == "0":
                self._activo = False
            else:
                imprimir_error("Opción no válida")
                imprimir_pausa()
        self._activo = True

    def crear_venta_personalizada(self):
        imprimir_titulo("REGISTRAR VENTA")
        cliente_id = pedir_entero("Id del cliente: ")
        if cliente_id is None:
            imprimir_error("El id debe ser un número")
            imprimir_pausa()
            return

        imprimir_info("Productos disponibles:")
        for producto in self._controlador.productos.leer():
            print(f"  {producto}")

        items = []
        while True:
            producto_id = pedir_entero("\nId del producto (0 para terminar): ")
            if producto_id is None or producto_id == 0:
                break
            cantidad = pedir_entero("Cantidad: ")
            if cantidad is None or cantidad <= 0:
                imprimir_error("Cantidad inválida")
                continue
            items.append({"producto_id": producto_id, "cantidad": cantidad})

        exito, mensaje = self._controlador.crear({"cliente_id": cliente_id, "items": items})
        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)
        imprimir_pausa()

    def ver_factura(self):
        imprimir_titulo("FACTURA")
        id_venta = pedir_entero("Id de la venta: ")
        texto = self._controlador.factura(id_venta)
        if texto is None:
            imprimir_error("No existe esa venta")
        else:
            print(texto)
        imprimir_pausa()


class MenuCompras(MenuCRUD):
    def __init__(self, controlador):
        super().__init__(controlador, "COMPRAS")

    def ejecutar(self):
        while self._activo:
            imprimir_titulo(self._titulo)
            print(f"  1. Crear {self._controlador.nombre}")
            print("  2. Ver todos")
            print("  3. Buscar")
            print("  4. Ver por id")
            print("  5. Actualizar")
            print("  6. Eliminar")
            print("  7. Ver orden de compra")
            print("  0. Volver\n")
            opcion = input("Opción: ").strip()

            if opcion == "1":
                self.crear_compra_personalizada()
            elif opcion == "2":
                self.ver_todos()
            elif opcion == "3":
                self.buscar()
            elif opcion == "4":
                self.ver_por_id()
            elif opcion == "5":
                imprimir_error("Las compras registradas no se pueden modificar")
                imprimir_pausa()
            elif opcion == "6":
                imprimir_error("No se permite eliminar compras para conservar la trazabilidad del inventario.")
                imprimir_pausa()
            elif opcion == "7":
                self.ver_orden_compra()
            elif opcion == "0":
                self._activo = False
            else:
                imprimir_error("Opción no válida")
                imprimir_pausa()
        self._activo = True

    def crear_compra_personalizada(self):
        imprimir_titulo("REGISTRAR COMPRA")
        proveedor_id = pedir_entero("Id del proveedor: ")
        if proveedor_id is None:
            imprimir_error("El id debe ser un número")
            imprimir_pausa()
            return

        imprimir_info("Productos disponibles:")
        for producto in self._controlador.productos.leer():
            print(f"  {producto}")

        items = []
        while True:
            producto_id = pedir_entero("\nId del producto (0 para terminar): ")
            if producto_id is None or producto_id == 0:
                break
            cantidad = pedir_entero("Cantidad: ")
            if cantidad is None or cantidad <= 0:
                imprimir_error("Cantidad inválida")
                continue
            
            try:
                costo_unitario = float(input("Costo unitario ($): "))
            except ValueError:
                imprimir_error("Costo inválido")
                continue

            items.append({
                "producto_id": producto_id, 
                "cantidad": cantidad, 
                "costo_unitario": costo_unitario
            })

        exito, mensaje = self._controlador.crear({
            "proveedor_id": proveedor_id, 
            "items": items
        })
        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)
        imprimir_pausa()

    def ver_orden_compra(self):
        imprimir_titulo("ORDEN DE COMPRA")
        id_compra = pedir_entero("Id de la compra: ")
        texto = self._controlador.orden_compra(id_compra)
        if texto is None:
            imprimir_error("No existe esa compra")
        else:
            print(texto)
        imprimir_pausa()


class MenuPrincipal:
    def __init__(self):
        clientes = ClienteController()
        proveedores = ProveedorController()
        productos = ProductoController()
        ventas = VentaController(clientes, productos)
        compras = CompraController(proveedores, productos)

        self._activo = True
        self._menus = {
            "1": MenuCRUD(clientes, "CLIENTES"),
            "2": MenuCRUD(proveedores, "PROVEEDORES"),
            "3": MenuCRUD(productos, "PRODUCTOS"),
            "4": MenuVentas(ventas),
            "5": MenuCompras(compras),
        }

    def ejecutar(self):
        while self._activo:
            imprimir_titulo("SISTEMA DE VENTAS Y COMPRAS")
            print("  1. Clientes")
            print("  2. Proveedores")
            print("  3. Productos")
            print("  4. Ventas")
            print("  5. Compras")
            print("  0. Salir\n")
            opcion = input("Opción: ").strip()

            if opcion == "0":
                imprimir_info("¡Hasta luego! 👋")
                self._activo = False
            elif opcion in self._menus:
                self._menus[opcion].ejecutar()
            else:
                imprimir_error("Opción no válida")
                imprimir_pausa()


if __name__ == "__main__":
    try:
        MenuPrincipal().ejecutar()
    except KeyboardInterrupt:
        print("\nPrograma interrumpido por el usuario.")