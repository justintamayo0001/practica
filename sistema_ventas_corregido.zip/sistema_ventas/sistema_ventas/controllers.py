import os
from models import Cliente, Proveedor, Producto, Venta, Compra
from shared.json_manager import GestorJSON

BASE = os.path.join(os.path.dirname(__file__), "data")

class BaseController:
    modelo = None
    archivo = None
    nombre = "registro"

    def __init__(self):
        self.gestor = GestorJSON(os.path.join(BASE, self.archivo))
        self.campos = self.modelo.CAMPOS

    def leer(self):
        return [self.modelo.desde_diccionario(x) for x in self.gestor.leer()]

    def obtener(self, id_registro):
        if id_registro is None: return None
        return next((x for x in self.leer() if x.id == int(id_registro)), None)

    def _guardar_objetos(self, objetos):
        return self.gestor.guardar([x.a_diccionario() for x in objetos])

    def crear(self, datos):
        try:
            registros = self.leer()
            nuevo_id = max((x.id for x in registros), default=0) + 1
            valores = {c: datos.get(c, 0 if c == "stock" else "") for c in self.modelo.CAMPOS}
            for campo in self.modelo.OBLIGATORIOS:
                if not str(valores.get(campo, "")).strip():
                    return False, f"El campo {campo} es obligatorio."
            obj = self.modelo(nuevo_id, **valores)
            registros.append(obj)
            if not self._guardar_objetos(registros):
                return False, "No se pudo guardar el registro."
            return True, f"{self.nombre.capitalize()} creado con id {nuevo_id}."
        except (ValueError, TypeError, KeyError) as e:
            return False, str(e)

    def buscar(self, texto):
        texto = str(texto).casefold()
        return [o for o in self.leer() if texto in str(o.a_diccionario()).casefold()]

    def actualizar(self, id_registro, cambios):
        try:
            registros = self.leer()
            obj = next((x for x in registros if x.id == int(id_registro)), None)
            if obj is None: return False, "Registro no encontrado."
            valores = obj.a_diccionario()
            valores.update(cambios)
            valores["id"] = obj.id
            nuevo = self.modelo.desde_diccionario(valores)
            registros = [nuevo if x.id == obj.id else x for x in registros]
            if not self._guardar_objetos(registros): return False, "No se pudo guardar."
            return True, "Registro actualizado."
        except (ValueError, TypeError, KeyError) as e:
            return False, str(e)

    def eliminar(self, id_registro):
        registros = self.leer()
        nuevo = [x for x in registros if x.id != int(id_registro)]
        if len(nuevo) == len(registros): return False, "Registro no encontrado."
        if not self._guardar_objetos(nuevo): return False, "No se pudo guardar."
        return True, "Registro eliminado."

class ClienteController(BaseController):
    modelo, archivo, nombre = Cliente, "clientes.json", "cliente"

class ProveedorController(BaseController):
    modelo, archivo, nombre = Proveedor, "proveedores.json", "proveedor"

class ProductoController(BaseController):
    modelo, archivo, nombre = Producto, "productos.json", "producto"

class MovimientoController(BaseController):
    def __init__(self, entidad_controller, productos):
        super().__init__()
        self.entidad_controller = entidad_controller
        self.productos = productos
        self.campos = self.modelo.CAMPOS

    def crear(self, datos):
        try:
            entidad_id = int(datos.get(self.campo_entidad))
            if self.entidad_controller.obtener(entidad_id) is None:
                return False, f"No existe {self.campo_entidad.replace('_id','')} con id {entidad_id}."
            items = datos.get("items", [])
            if not items: return False, "Agregue al menos un producto."
            productos = self.productos.leer()
            mapa = {p.id:p for p in productos}
            detalles = []
            acumulados = {}
            for item in items:
                pid, cantidad = int(item["producto_id"]), int(item["cantidad"])
                if cantidad <= 0: return False, "La cantidad debe ser mayor a cero."
                p = mapa.get(pid)
                if p is None: return False, f"No existe producto con id {pid}."
                acumulados[pid] = acumulados.get(pid, 0) + cantidad
                if self.tipo == "venta":
                    if acumulados[pid] > p.stock:
                        return False, f"Stock insuficiente de {p.nombre}: disponible {p.stock}."
                    detalles.append((p, cantidad, p.precio))
                else:
                    costo = float(item["costo_unitario"])
                    if costo <= 0: return False, "El costo unitario debe ser mayor a cero."
                    detalles.append((p, cantidad, costo))
            registros = self.leer()
            nuevo_id = max((x.id for x in registros), default=0) + 1
            if self.tipo == "venta":
                obj = Venta(nuevo_id, entidad_id)
                for p,c,_ in detalles: obj.agregar_detalle(p,c)
                for pid,c in acumulados.items(): mapa[pid].descontar_stock(c)
            else:
                obj = Compra(nuevo_id, entidad_id)
                for p,c,costo in detalles: obj.agregar_detalle(p,c,costo)
                for pid,c in acumulados.items(): mapa[pid].aumentar_stock(c)
            if not self.productos._guardar_objetos(list(mapa.values())):
                return False, "No se pudo actualizar el inventario."
            registros.append(obj)
            if not self._guardar_objetos(registros):
                # Rollback del stock si falla el guardado del movimiento
                productos_actualizados = self.productos.leer()
                for p in productos_actualizados:
                    if p.id in acumulados:
                        if self.tipo == "venta": p.aumentar_stock(acumulados[p.id])
                        else: p.descontar_stock(acumulados[p.id])
                self.productos._guardar_objetos(productos_actualizados)
                return False, "No se pudo guardar el movimiento; inventario restaurado."
            return True, f"{self.nombre.capitalize()} registrada con id {nuevo_id}. Total: ${obj.total:.2f}"
        except (ValueError, TypeError, KeyError) as e:
            return False, str(e)

    def factura(self, id_registro):
        obj = self.obtener(id_registro)
        if obj is None: return None
        cliente = self.entidad_controller.obtener(obj.cliente_id)
        lineas = [f"FACTURA #{obj.id}", f"Fecha: {obj.fecha}", f"Cliente: {cliente.nombre_completo if cliente else obj.cliente_id}", "-"*40]
        lineas += [f"{d.cantidad} x {d.descripcion} @ ${d.precio_unitario:.2f} = ${d.subtotal:.2f}" for d in obj.detalles]
        lineas += ["-"*40, f"TOTAL: ${obj.total:.2f}"]
        return "\\n".join(lineas)

    def orden_compra(self, id_registro):
        obj = self.obtener(id_registro)
        if obj is None: return None
        proveedor = self.entidad_controller.obtener(obj.proveedor_id)
        lineas = [f"ORDEN DE COMPRA #{obj.id}", f"Fecha: {obj.fecha}", f"Proveedor: {proveedor.nombre_completo if proveedor else obj.proveedor_id}", "-"*40]
        lineas += [f"{d.cantidad} x {d.descripcion} @ ${d.costo_unitario:.2f} = ${d.subtotal:.2f}" for d in obj.detalles]
        lineas += ["-"*40, f"TOTAL: ${obj.total:.2f}"]
        return "\\n".join(lineas)

class VentaController(MovimientoController):
    modelo, archivo, nombre, campo_entidad, tipo = Venta, "ventas.json", "venta", "cliente_id", "venta"
    def __init__(self, clientes, productos): super().__init__(clientes, productos)

class CompraController(MovimientoController):
    modelo, archivo, nombre, campo_entidad, tipo = Compra, "compras.json", "compra", "proveedor_id", "compra"
    def __init__(self, proveedores, productos): super().__init__(proveedores, productos)
